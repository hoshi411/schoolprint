const CACHE_NAME = 'BZvA1-8';
const urlsToCache = [
    '/', 
    'index.html', 
    'sw.js', 
    'manifest.json',
    'img/*.png',
    'img/*.svg',
    'img/*.webp',
    'css/*.css',
    'font/*.ttf'
];






self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
      .catch(error => console.log('Cache addAll failed: ', error))
  );
});





self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response;
        }

        return fetch(event.request)
          .then(response => {
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            const responseToCache = response.clone();
            caches.open(CACHE_NAME)
              .then(cache => cache.put(event.request, responseToCache));

            return response;
          });
      })
  );
});




self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];

  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});






//MESSAGE IF UPDATE AVAILABLE
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});

// Check for updates
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      fetch('version.txt')
        .then(response => response.text())
        .then(version => {
          console.log(`Current version: ${version}`);
          cache.match('version.txt').then(response => {
            if (response && response.text() !== version) {
              console.log(`New version available: ${version}`);
              self.registration.showNotification('New version available', {
                body: 'Click to update the app',
                icon: 'BZ192.png',
                tag: 'new-version',
                actions: [
                  { action: 'update', title: 'Update' },
                  { action: 'ignore', title: 'Ignore' }
                ]
              });
            }
          });
        });
    })
  );
});

// Handle notification actions
self.addEventListener('notificationclick', event => {
  if (event.notification.tag === 'new-version') {
    if (event.action === 'update') {
      event.waitUntil(
        caches.keys().then(cacheNames => {
          return Promise.all(
            cacheNames.map(cacheName => {
              if (cacheName.startsWith('BZv')) {
                return caches.delete(cacheName);
              }
            })
          );
        })
        .then(() => {
          console.log('Caches deleted');
          self.registration.unregister();
          location.reload();
        })
      );
    }
  }
  event.notification.close();
});
