//PAGELOAD ACTIONS
/////////////////////

var protectedState = "";
var saveToggle = false;
$(document).ready(function(){

if(saveToggle){}else{
    saveLocal(); 
    var saveToggle = true;
}

});
    





































$(document).on("mouseenter", ".BINGO⟪GRID > figure", function() {
  $(this).append($("#CELL⟪TOOLBOX⟪TMP").html());
}).on("mouseleave", ".BINGO⟪GRID > figure", function() {
  $(".CELL⟪TOOLBOX").remove();
});


$(document).on("mouseenter", ".DOCS⟪MENU > button", function() {
  $(this).append($("#DIALOG⟪TOOLBOX⟪TMP").html());
}).on("mouseleave", ".DOCS⟪MENU > button", function() {
  $(".CELL⟪TOOLBOX").remove();
});


































var hoverTimeout;
$(document).on("mouseover","[data-gloss]", function(event) {
  clearTimeout(hoverTimeout);

  $(".INFO⟪TIPS").attr("data-gloss", $(this).attr("data-gloss"));

  hoverTimeout = setTimeout(function() {
    var left = event.pageX - $(".INFO⟪TIPS").width() * 1.4;
    var top = event.pageY - $(".INFO⟪TIPS").height() * 1.2;

    $(".INFO⟪TIPS").css({
      left: "max(0px," + left + "px)",
      top: top + "px",
    }).removeClass("JAVA⟪HIDE");

  }, 2000);
}).on("mouseout", function() {
  clearTimeout(hoverTimeout);
  $(".INFO⟪TIPS").addClass("JAVA⟪HIDE");
});

































/* CLICK ON STUFF
// MAKE IT WORK
/////////////////////// */

var fontZoom = 100;
$(document).on("click", ".FONTUP⟪BTN", function() { 
// INCREASE FONT SIZE

  if (fontZoom <= 300) {
    fontZoom += 15;
    $("figure s1,figure small").css({
      zoom: fontZoom + "%"
    });
  }
});

$(document).on("click", ".FONTDOWN⟪BTN", function() { 
//DECREASE FONT SIZE

  if (fontZoom >= 40) {
    fontZoom -= 15;
    $("figure s1,figure small").css({
      zoom: fontZoom + "%"
    });
  }

});

var imgZoom = 100;
$(document).on("click", ".IMGUP⟪BTN", function() { 
//INCREASE IMAGE SIZE
    
    if (imgZoom <= 500) {
    imgZoom += 15;
    $("figure img").css({
      zoom: imgZoom + "%"
    });
  }
});

$(document).on("click", ".IMGDOWN⟪BTN", function() { 
//DECREASE IMAGE SIZE

    if (imgZoom >= 50) {
    imgZoom -= 15;
    $("figure img").css({
      zoom: imgZoom + "%"
    });
  }
});





$(document).on("click", ".ADDIMAGE⟪BTN", function() {
  // Get the parent <figure> tag of the clicked button
  var figure = $(this).closest('figure');

  // Prompt the user to select an image
  var input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = function(event) {
    var file = event.target.files[0];

    // Create a FileReader to read the selected image
    var reader = new FileReader();
    reader.onload = function(event) {
      var imageDataUrl = event.target.result;

      // Update the background-image URL of the .CELL⟪IMG element inside the parent <figure> tag
      figure.find('.CELL⟪IMG').css('background-image', 'url(' + imageDataUrl + ')').addClass("⟪IMG");
    };
    reader.readAsDataURL(file);
  };
  input.click();

  trackChanges(); // UPDATE UNDO HISTORY
});







$(document).on("click", ".ADDCOLUMN⟪BTN", function() { 
//ADD A NEW COLUMN
    var currentColumns = $(".BINGO⟪GRID").css("grid-template-columns").split(" ").length;
    var currentRows = $(".BINGO⟪GRID").css("grid-template-rows").split(" ").length;


    for (var i = 0; i < currentRows; i++) {
    $(".BINGO⟪GRID").css("grid-template-columns", "repeat(" + (currentColumns + 1 ) +", 1fr)");

    var figureClone = $('#GRIDCELL⟪TMP').contents().clone();

   figureClone.css("order", $(".BINGO⟪GRID > figure").length++);


    $(".BINGO⟪GRID").append(figureClone);
   
    }

    trackChanges(); //UPDATE UNDO HISTORY
});

$(document).on("click", ".DELCOLUMN⟪BTN", function() { 
//DELETE A COLUMN
    var currentColumns = $(".BINGO⟪GRID").css("grid-template-columns").split(" ").length;
    var currentRows = $(".BINGO⟪GRID").css("grid-template-rows").split(" ").length;

if(currentColumns >= 3){

    for (var i = 0; i < currentRows; i++) {
    $(".BINGO⟪GRID").css("grid-template-columns", "repeat(" + (currentColumns - 1 ) +", 1fr)");

    $(".BINGO⟪GRID figure:last-child").remove();
    }

    trackChanges(); //UPDATE UNDO HISTORY
 }
});








$(document).on("click", ".ADDROW⟪BTN", function() { 
//ADD A NEW COLUMN
    var currentColumns = $(".BINGO⟪GRID").css("grid-template-columns").split(" ").length;
    var currentRows = $(".BINGO⟪GRID").css("grid-template-rows").split(" ").length;

    

    for (var i = 0; i < currentColumns; i++) {
    $(".BINGO⟪GRID").css("grid-template-rows", "repeat(" + (currentRows + 1 ) +", 1fr)");




    var figureClone = $('#GRIDCELL⟪TMP').contents().clone();
   figureClone.css("order", $(".BINGO⟪GRID > figure").length++);
    $(".BINGO⟪GRID").append(figureClone);


/* 
    $(".BINGO⟪GRID").append($("#GRIDCELL⟪TMP").html());
*/

    }



    trackChanges(); //UPDATE UNDO HISTORY
});



$(document).on("click", ".DELROW⟪BTN", function() { 
//DELETE A ROW
    var currentColumns = $(".BINGO⟪GRID").css("grid-template-columns").split(" ").length;
    var currentRows = $(".BINGO⟪GRID").css("grid-template-rows").split(" ").length;

if(currentRows >= 3){

    for (var i = 0; i < currentColumns; i++) {
    $(".BINGO⟪GRID").css("grid-template-rows", "repeat(" + (currentRows - 1 ) +", 1fr)");

    $(".BINGO⟪GRID figure:last-child").remove();
    }

    trackChanges(); //UPDATE UNDO HISTORY
 }
});




$(document).on("click", ".ROTATE⟪BTN", function() { 
//ROTATE THE FRAME PORTRAIT LANDSCAPE
    $(".PAGE⟪BORDER").toggleClass("JAVA⟪PORTRAIT");
    $(".BIGCARD⟪PAGES .BINGO⟪GRID figure").toggleClass("JAVA⟪PORTRAIT");

    trackChanges(); //UPDATE UNDO HISTORY
});


$(document).on("click", ".CARDS⟪BTN", function() { 
//SWITCH TO CARD CUTOUT MODE
    $(".BINGO⟪GRID").toggleClass("CARDS⟪GRID");

    trackChanges(); //UPDATE UNDO HISTORY
});



//TURN MODALS INTO VARIABLES
var dialog = document.querySelector('dialog.DOCS⟪MODAL');
var pkgDialog = document.querySelector('dialog.PACKAGE⟪MODAL');
var autogenDialog = document.querySelector('dialog.AUTO⟪MODAL');

var protectedState = "";
$(document).on("click", ".OPEN⟪BTN", function() { 
//LAUNCH DOCUMENT MODAL AND
//POPULATE WITH LOCAL STORAGE DOCS

//save html state from modal reset bug
protectedState = $(".PAGE⟪BORDER").prop("outerHTML");

trackChanges(); //update history before showing

dialog.showModal();

respawnDocuments();

});

function respawnDocuments(){

//CLEAR DOCS⟪MENU first
$(".DOCS⟪MENU > *").remove();

//add each doc to embed src
for (var key in localStorage) {
    if (localStorage.hasOwnProperty(key) && key.startsWith('doc-')) {
       
var pageName = key.substring(4);

//clone some data
var savedHTML = localStorage.getItem(key);
var buttonClone = $('#LOCALDOCS⟪TMP').contents().clone();

gridClone = $(savedHTML).find(".BINGO⟪GRID");
// Modify the cloned templates
buttonClone.find("figure").html(gridClone);
buttonClone.find("span").text(pageName);

// Insert the cloned template into the DOM
$(".DOCS⟪MENU").append(buttonClone);

    }
}



}



$(document).on("click", ".BACK⟪BTN", function() { 
//CLOSE DIALOG
    dialog.close();
pkgDialog.close();
autogenDialog.close();
});


$(document).on("click", ".NEWFILE⟪BTN", function() { 
//LAUNCH A NEW PAGE
    window.open("https://bingozukan.netlify.app","_blank","toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=yes, width=900, height=700");

});




$(document).on("click", ".EXPORTFILE⟪BTN", function(event) { 
//EXPORT DOC TO EXTERNAL FILE
event.stopPropagation();

    //get saveable content
    var docLabel = $("button:hover span").html();

    var localItem = protectedState;
    if(docLabel = "New Document"){}else{
        localItem = localStorage.getItem("doc-"+docLabel);
    }

    // Create a Blob object with the HTML string
    const blob = new Blob([localItem], { type: 'text/html' });
    // Create a temporary link element
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = docLabel + '.html';
    // Click the link to trigger the download
    link.click();  
    // Clean up the link element
    document.body.removeChild(link);



});











$(document).on("click", ".IMPORT⟪BTN", function() { 
//IMPORT SAVED HTML BACKUP
//ADD IT TO LOCALSTORAGE


    $("#fileInput").click().on("change", function() {
        // Get the selected file
        var file = $("#fileInput").prop("files")[0];
        // Create a file reader object
        var reader = new FileReader();

        // Set up the onload event handler
        reader.onload = function(event) {
        // Get the file content as a string
        var content = event.target.result;

        /* FIGURE OUT THE DOC NAME
        FROM THE FILE NAME */
        var filePath = $("#fileInput").val(); 
        var fileName = filePath.substring(filePath.lastIndexOf('\\') + 1);
        var docName = fileName.slice(0, -5); 

        // Set docName as key and set content as value in localStorage
        localStorage.setItem("doc-" + docName, content);

         respawnDocuments();

        };

        // Read the file as text
        reader.readAsText(file);

       
    });





});






















$(document).on("click", ".DELETEFILE⟪BTN", function(event) { 
//DELETE DOC FROM LOCALSTORAGE
event.stopPropagation();

var thisDocName = $("button:hover span").text();

localStorage.removeItem("doc-" + thisDocName);

respawnDocuments();
});






$(document).on("click", ".DOCS⟪MENU > button", function() {
  // OPEN THE FILE THAT WAS CLICKED ON

  // Get docname of button clicked
  var docName = $(this).find("span").text();

  var savedPageHTML = localStorage.getItem("doc-" + docName);

  $(".PAGE⟪BORDER").replaceWith(savedPageHTML);
  $("title").text(docName);
    $(".DOC⟪TITLE > span").text(docName);

dialog.close();
});









//PROMPT FOR WEB APP BEFORE
//MOVING TO ELECTRON APP FORMAT
////////////////////////////////////

/* 
$(document).on("click", ".DUPLICATEFILE⟪BTN", function(event) { 
//DUPLICATE FILE AND NEW NAME
event.stopPropagation();

//get this doc name and value
var thisDocName = $("button:hover span").text();
var thisDocValue = localStorage.getItem("doc-"+ thisDocName);
var userDocName = prompt("Document Name");

//create new local doc
localStorage.setItem("doc-" + userDocName, thisDocValue);

respawnDocuments();
});
 */








$(document).on("click", ".DUPLICATEFILE⟪BTN", function(event) {
  // DUPLICATE FILE AND NEW NAME
  event.stopPropagation();

  // Get this doc name and value
  var thisDocName = $("button:hover span").text();
  var thisDocValue = localStorage.getItem("doc-" + thisDocName);





  // Create a dialog element
  var dialog = document.createElement('dialog');
  dialog.className = 'JAVA⟪PROMPT';

  // Create an input element
  var label = document.createElement('h2');
    label.textContent = 'Enter new name';
  var input = document.createElement('input');
  input.type = 'text';

  // Create a cancel button
  var cancelButton = document.createElement('button');
  cancelButton.textContent = 'Cancel';

  // Handle the Enter key press event
  input.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
      userDocName = input.value;
      dialog.close();
      // Create new local doc
      localStorage.setItem("doc-" + userDocName, thisDocValue);
      respawnDocuments();
    }
  });

  // Handle the Cancel button click event
  cancelButton.addEventListener('click', function() {
    dialog.close();
  });

  // Append the input and cancel button to the dialog
   dialog.appendChild(label);
    dialog.appendChild(input);
  dialog.appendChild(cancelButton);

  // Open the dialog
  document.body.appendChild(dialog);
  dialog.showModal();
});



































var fontScale = 1;
$(document).on("click", ".SQUEEZE⟪BTN", function() { 
//SQUISH TEXT TO FIT
var figure = $(this).closest('figure');

 if (fontScale >= 0.5) {
    fontScale -= 0.1;
    $(figure).find("s1").css({
      scale: fontScale + " 1"
    });
  }

});



$(document).on("click", ".EXPAND⟪BTN", function() { 
//EXPAND TEXT TO FIT
var figure = $(this).closest('figure');

 if (fontScale <= 1.9) {
    fontScale += 0.1;
    $(figure).find("s1").css({
      scale: fontScale + " 1"
    });
  }

});



$(document).on("click", ".CLEARCELL⟪BTN", function() { 
//RESET THE CELL TO DEFAULT
var figure = $(this).closest('figure');

$(figure).find(".⟪IMG").removeClass("⟪IMG");
$(figure).find(".CELL⟪TXT s1").removeAttr("style");
$(figure).find(".CELL⟪IMG").removeAttr("style");
$(figure).find("small").addClass("JAVA⟪NONE");

});


































var startNumber = 0;
$(document).on("click", ".SWAPCELL⟪BTN", function() {
  // GET LOCATION OF FIRST CELL
  // START HIGHLIGHTS
  var figure = $(this).closest('figure');
  figure.addClass("START⟪LIGHT");
  $(".BINGO⟪GRID").addClass("GRID⟪LIGHT");


  startNumber = figure.css('order');

});


$(document).on("click", ".GRID⟪LIGHT > figure", function() {
  // GET LOCATION OF END CELL
  // SWITCH ORDER START AND END
  // TURN OFF LIGHTS
  var endFigure = $(this);

  endNumber = endFigure.css('order');


  $(".START⟪LIGHT").css("order", endNumber);
  endFigure.css("order", startNumber);


  $(".START⟪LIGHT").removeClass("START⟪LIGHT");
  $(".GRID⟪LIGHT").removeClass("GRID⟪LIGHT");
});





$(document).on("click", ".SMALL⟪BTN", function() { 
//ADD SMALL TEXT
  var figure = $(this).closest('figure');
$(figure).find("small").toggleClass("JAVA⟪NONE");
});


























/* LETS ADD UNDO 
// AND REDO FUNCTIONS
////////////////////// */

// Arrays to store states
var pageStates = [];
var undoStates = [];
var redoStates = [];

// Function to track changes 
// and store page state
function trackChanges() {

  // Get the current state of the page
  var currentState = $(".PAGE⟪BORDER").html();

  // Add the current state to the array
  pageStates.push(currentState);

  // Keep only the last 10 states
  if (pageStates.length > 20) {
    pageStates.shift();
  }

  // Clear the redo stack 
  //whenever a new change is made
  redoStates = [];

    //SAVE TO LOCAL DATA
    saveLocal();
}

// Function to undo 
// the last page state
function undo() {
  // Check if any previous states to undo to
  if (pageStates.length > 1) {
    // Get the previous state from the array
    var previousState = pageStates.pop();

    // Add the current state to the redo array
    redoStates.push($(".PAGE⟪BORDER").html());

    // Update the page with the previous state
    $(".PAGE⟪BORDER").html(pageStates[pageStates.length - 1]);

    //SAVE TO LOCAL DATA
    saveLocal();

    // Add the previous state to the undo array
    undoStates.push(previousState);
  }
}

// Function to redo the 
//last undone state
function redo() {
  // Check if any newer states to redo to
  if (redoStates.length > 0) {
    // Get the next state from the redo array
    var nextState = redoStates.pop();

    // Add the current state to the undo array
    undoStates.push($(".PAGE⟪BORDER").html());

    // Update the page with the next state
    $(".PAGE⟪BORDER").html(nextState);

    //SAVE TO LOCAL DATA
    saveLocal();

    // Add the next state to the pageStates array
    pageStates.push(nextState);
  }
}


// Call trackChanges 
// whenever text input changes happen
$(document).on('input', function() {
  //trackChanges(); //UPDATE UNDO HISTORY
//pause this for now since it causes issues with
// the documents modal dialog box
});





$(document).on("click", ".UNDO⟪BTN", function() { 
//UNDO EVENTS
    undo();

});



$(document).on("click", ".REDO⟪BTN", function() { 
//UNDO EVENTS
    redo();

});








$(document).on("click", ".RESET⟪BTN", function() { 
//RESET THE DOCUMENT
    location.reload();
    trackChanges(); //UPDATE UNDO HISTORY
});






$(document).on("click", ".AUTO⟪BTN", function() { 
//OPEN AUTOGEN MODAL

    autogenDialog.showModal();

});


$(document).on("click", ".PRINT⟪BTN", function() { 
//OPEN PACKAGING DIALOG
pkgDialog.showModal();

});


$(document).on("click", ".PDF⟪BTN", function() { 
//OPEN PDF PRINT TO SAVE A4 PDF

window.print();
});





var counter = 0;
$(document).on("click", ".MODEFLIP⟪BTN", function() { 
//TOGGLE THROUGH THREE MODES
//BINGO / MINI / BIGCARD

counter++;
    
if (counter === 1) {
    // Function 1 MINICARDS
    $(".PAGE⟪BORDER").removeClass("BIGCARD⟪PAGES");
    $(".BINGO⟪GRID").addClass("CARDS⟪GRID");
    $("figure").removeClass("JAVA⟪PORTRAIT");
} else if (counter === 2) {
    // Function 2 BIG CARDS
    $(".BINGO⟪GRID").removeClass("CARDS⟪GRID");
    $(".PAGE⟪BORDER").addClass("BIGCARD⟪PAGES");
} else if (counter === 3) {
    // Function 3 BINGO GRID
    $(".PAGE⟪BORDER").removeClass("BIGCARD⟪PAGES");
    $(".BINGO⟪GRID").removeClass("CARDS⟪GRID");
    $("figure").removeClass("JAVA⟪PORTRAIT");
    // Reset the counter to start from the first function
    counter = 0;
}


});





/* 

//OLD FUNCTION GENERATES LARGE RANDOM
//NUMBER FOR EACH FIGURE.

$(document).on("click", ".SHUFFLE⟪BTN", function() {
  // Get the total number of figure elements
  var totalFigures = $(".BINGO⟪GRID figure").length;

  // Loop through each figure element
  $(".BINGO⟪GRID figure").each(function(index) {
    // Generate a random order value between 1 and the total number of figures
    var randNum = Math.floor(Math.random() * totalFigures) + 1;

    // Set the order CSS property of the current figure element
    $(this).css("order", randNum);
  });
});

 */



$(document).on("click", ".SHUFFLE⟪BTN", function() {
  // Get the total number of figure elements
  var totalFigures = $(".BINGO⟪GRID > figure").length;

  // Create an array of numbers from 1 to totalFigures
  var figureOrder = Array.from({ length: totalFigures }, (_, index) => index + 1);

  // Shuffle the array in random order
  for (var i = figureOrder.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    [figureOrder[i], figureOrder[j]] = [figureOrder[j], figureOrder[i]];
  }

  // Loop through each figure element and set the CSS order property
  $(".BINGO⟪GRID figure").each(function(index) {
    $(this).css("order", figureOrder[index]);
  });
});






























$(document).on("click", ".TEXTBUILD⟪BTN", function() {
  // AUTO GENERATE GRID FROM WORDS
  // TEXT THE USER INPUTS

  // Split the user input into an array from commas
  var wordArray = $(".WORDLIST").val().split(",");

  var wordNum = wordArray.length;

  // Split wordNum into two 
  //numbers which are its largest factors
  var factors = findLargestFactors(wordNum);
  var rowNum = factors[0];
  var colNum = factors[1];

    //create grid frame
    autogenGrid(colNum,rowNum);

    //populate grid with wordArray
    wordFeeder(wordArray);



  trackChanges(); //UPDATE UNDO HISTORY
  autogenDialog.close(); //close dialog
});


//FIND LARGEST FACTORS FOR AUTOGEN
///////////////////////////////////
function findLargestFactors(num) {
  // Check if num is a perfect square
  var sqrt = Math.sqrt(num);
  if (Number.isInteger(sqrt)) {
    // num is a perfect square, find factors as usual
    var factors = [];
    for (var i = Math.floor(sqrt); i >= 1; i--) {
      if (num % i === 0) {
        factors.push(i, num / i);
        break;
      }
    }
    return factors;
  } else {
    // num is not a perfect square, round it to the next near perfect square
    var nextSquare = Math.ceil(sqrt) ** 2;
    return findLargestFactors(nextSquare);
  }
}


//CREATE GRID BASED ON NUMBERS
///////////////////////////////
function autogenGrid(colNum , rowNum){
    //clear the grid
    $(".BINGO⟪GRID figure").remove();




    //MAKE NEEDED CELLS
    var neededCells = colNum * rowNum;
    for (var i = 0; i < neededCells; i++) {
        var figureClone = $('#GRIDCELL⟪TMP').contents().clone();
        figureClone.css("order", $(".BINGO⟪GRID > figure").length++ );
        $(".BINGO⟪GRID").append(figureClone);
    }

    //ORGANIZE CELLS INTO GRID
    $(".BINGO⟪GRID").css("grid-template-columns", "repeat(" + colNum +", 1fr)");
    $(".BINGO⟪GRID").css("grid-template-rows", "repeat(" + rowNum +", 1fr)");

}

//POPULATE GRID WITH AUTOGEN WORDS
function wordFeeder(wordArray){

        //wordNum is the number of figure elements inside of .BINGO⟪GRID
        var figures = $(".BINGO⟪GRID s2");

        //add each word from wordArray to each figure element in .BINGO⟪GRID
        figures.each(function(index) {
            $(this).text(wordArray[index]);
        });
}







































$(document).on("click", ".FOLDERBUILD⟪BTN", function() { 
//BUILD GRID FROM FOLDER OF IMAGES


// Open file input dialog 
//to select multiple images
/////////////////////////////////////
var input = document.createElement('input');
input.type = 'file';
input.multiple = true;
input.accept = 'image/*';

// var imgNum = 0;
input.addEventListener('change', function(event) {
    var fileList = event.target.files;
    // Convert FileList to an 
    //array of image URLs
    var imgArray = Array.from(fileList).map(function(file) {
    return URL.createObjectURL(file);
    });


    // Split wordNum into two 
    //numbers which are its largest factors
    ///////////////////////////////////////
    var imgNum = imgArray.length;
    var factors = findLargestFactors(imgNum);
    var rowNum = factors[0];
    var colNum = factors[1];

    //create grid frame
    autogenGrid(colNum,rowNum);

    //populate grid with imgArray
    imgFeeder(imgArray);

});

// Trigger the file input dialog
input.click();



trackChanges(); //UPDATE UNDO HISTORY
autogenDialog.close(); //close dialog
});






// POPULATE GRID WITH IMAGES FROM ARRAY
function imgFeeder(imgArray) {
  // Get all the figure elements inside .BINGO⟪GRID
  var figures = $(".BINGO⟪GRID figure");


figures.each(function(index) {
  var imgElement = $(this).find(".CELL⟪IMG");
  if (imgArray[index]) {
    imgElement.css('background-image', 'url(' + imgArray[index] + ')').addClass("⟪IMG");
  }
});




  //SCALEDOWN IMAGES
    $(".PAGE⟪BORDER").addClass("JAVA⟪PORTRAIT");


}





























//GET IMAGES FROM DRAG AND DROP
//PUSH THEM TO THE GRID
$(document).ready(function() {

//stop defaults
$(".IMG⟪DROP").on("dragover", function(e) {
    $(".IMG⟪DROP").addClass("IMG⟪DROP⟪HOVER");
    e.preventDefault();
});
$(".IMG⟪DROP").on("dragleave", function(e) {
    e.preventDefault();
    $(".IMG⟪DROP").removeClass("IMG⟪DROP⟪HOVER");
});
$(".IMG⟪DROP").on("drop", function(e) {
    e.preventDefault();



// Get the dropped files
var files = e.originalEvent.dataTransfer.files;


var imgArray = Array.from(files).map(function(file) {
    return URL.createObjectURL(file);
});


// Split wordNum into two 
//numbers which are its largest factors
///////////////////////////////////////
var imgNum = files.length;
var factors = findLargestFactors(imgNum);
var rowNum = factors[0];
var colNum = factors[1];


//create grid frame
autogenGrid(colNum,rowNum);

//populate grid with imgArray
imgFeeder(imgArray);


autogenDialog.close(); //close dialog
$(".IMG⟪DROP").removeClass("IMG⟪DROP⟪HOVER");
trackChanges(); //UPDATE UNDO HISTORY
});

});





















$(document).on("click", ".BTNNAME", function() { 
//DOSOMETHING

});



























/* WHAT HAPPENS WHEN WE
SAVE CURRENT STATE TO LOCAL
//////////////////////////// */
function saveLocal() {

var docTitle = $("title").text();

/*SHOULD I SAVE THE FULL PAGE OR JUST PARTIAL
//////////////////////////////////////////////
////////////////////////////////////////////// */
// var saveData = $(".PAGE⟪BORDER")[0].outerHTML;
// var currentPage = $("html")[0].outerHTML;
var currentHTML = $(".PAGE⟪BORDER").prop("outerHTML");

// var saveData = $(".PAGE⟪BORDER")[0].outerHTML;
localStorage.setItem("doc-" + docTitle, currentHTML);

}





















//END OF FILE
